let mysql = require('mysql')
// let fs = require('fs')

pool = mysql.createPool({
  host: 'cacmarket.com',
  user: 'cacliftp_cacmarket',
  password: '&8oEc9*).~sf',
  database: 'cacliftp_cacmarket'
})

pool.getConnection(function(err) {
    if (err) {
      return console.error('error: ' + err.message);
    }
    console.log('Connected to the MySQL server.');
    return pool
})

module.exports = pool